﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
[assembly: AssemblyTitle("SidusGroundStation")]
[assembly: AssemblyDescription("Sidus Ground Station")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Sidus")]
[assembly: AssemblyProduct("Sidus Ground Station")]
[assembly: AssemblyCopyright("Copyright ©  2016")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("c20f0679-dfab-4bfc-8fe6-e787226c5ac6")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
