﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Maps.MapControl.WPF;

namespace SidusAvionicsInstrumentControls
{
    public partial class gsSidus : Form
    {
        public gsSidus()
        {
            InitializeComponent();
            bckWGauges.WorkerReportsProgress = true;
            bckWGauges.DoWork += new DoWorkEventHandler(bckWGauges_DoWork);
        }

        private void bckWGauges_DoWork(object sender, DoWorkEventArgs e)
        {
            Random rnd = new Random();
            while (true)
            {
                int rand = rnd.Next(0, 800);
                System.Threading.Thread.Sleep(200);
                airSpeedInstrumentControl1.SetAirSpeedIndicatorParameters(rand);
                //airSpeedInstrumentControl1.BeginInvoke(new Action(delegate () { list.Items.Add(name1 + " dosyasının ismi değişti"); }));
                airSpeedInstrumentControl1.Refresh();
            }
        }

        //public void airSpeedInstrumentControlBegIn()
        //{
        //    airSpeedInstrumentControl1.BeginInvoke(new Action(delegate () { list.Items.Add(name1 + " dosyasının ismi değişti"); }));
        //}

        private void gsSidus_Load(object sender, EventArgs e)
        {
            System.Windows.Forms.Form.CheckForIllegalCrossThreadCalls = false;
            bckWGauges.RunWorkerAsync();
        }
    }
}
